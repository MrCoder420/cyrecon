# CyRecon

CyRecon is an automated recon toolkit with AI features for:

- Subdomain scanning 🕵️‍♂️
- Port scanning with AI risk analysis 🚨
- Directory brute-forcing 📂
- CVE suggestion matching 🧠
- PDF/JSON reporting 📄
